/**
 * Spring Framework configuration files.
 */
package com.finastra.party.config;
