/**
 * Data Transfer Objects.
 */
package com.finastra.party.service.dto;
