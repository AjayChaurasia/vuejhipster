/**
 * Service layer beans.
 */
package com.finastra.party.service;
