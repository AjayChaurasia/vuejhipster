/**
 * Spring MVC REST controllers.
 */
package com.finastra.party.web.rest;
