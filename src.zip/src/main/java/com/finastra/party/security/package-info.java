/**
 * Spring Security configuration.
 */
package com.finastra.party.security;
