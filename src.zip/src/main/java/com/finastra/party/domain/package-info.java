/**
 * JPA domain objects.
 */
package com.finastra.party.domain;
