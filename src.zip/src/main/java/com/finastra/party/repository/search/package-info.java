/**
 * Spring Data Elasticsearch repositories.
 */
package com.finastra.party.repository.search;
