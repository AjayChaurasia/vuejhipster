import Vue from 'vue'
import component from './vuetify/lib/components'
import {
  Vuetify,
  VApp,
  VNavigationDrawer,
  VFooter,
  VList,
  VBtn,
  VIcon,
  VGrid,
  VToolbar,
  VTooltip, // added
  VCheckbox, // added
  VDataTable,VTextField,VRadio,VRadioGroup,VLayout,VCard,
  transitions
} from 'vuetify'
import 'vuetify/src/stylus/app.styl'

Vue.use(Vuetify, {
  components: {
    VApp,
    VNavigationDrawer,
    VFooter,
    VList,
    VBtn,
    VIcon,
    VGrid,
    VToolbar,
    VTooltip, // added
    VCheckbox, // added
    VDataTable,VTextField,VRadio,VRadioGroup,VLayout,VCard,
    transitions
  },
  theme: {
    primary: '#0D47A1',
    secondary: '#424242',
    accent: '#82B1FF',
    error: '#FF5252',
    info: '#2196F3',
    success: '#4CAF50',
    warning: '#FFC107'
  },
})

Vue.use(component);


/*import Vue from 'vue'
import Vuetify from 'vuetify/lib/index.js'
import 'vuetify/src/stylus/app.styl'

Vue.use(Vuetify, {
  iconfont: 'md',
})*/
