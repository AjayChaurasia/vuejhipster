import Vue from 'vue';
import Router from 'vue-router';
import Home from '../components/home/Home.vue';
import Register from '../components/account/register/Register.vue';
import ResetPassword from '../components/account/reset-password/ResetPassword.vue';
import ChangePassword from '../components/account/change-password/ChangePassword.vue';
import Sessions from '../components/account/sessions/Sessions.vue';
import Settings from '../components/account/settings/Settings.vue';
import JhiConfigurationComponent from '../components/admin/configuration/Configuration.vue';
import JhiDocsComponent from '../components/admin/docs/Docs.vue';
import JhiHealthComponent from '../components/admin/health/Health.vue';
import JhiLogsComponent from '../components/admin/logs/Logs.vue';
import JhiAuditsComponent from '../components/admin/audits/Audits.vue';
import JhiMetricsComponent from '../components/admin/metrics/Metrics.vue';
import JhiUserManagementComponent from '../components/admin/user-management/UserManagement.vue';
import JhiUserManagementViewComponent from '../components/admin/user-management/UserManagementView.vue';
import JhiUserManagementEditComponent from '../components/admin/user-management/UserManagementEdit.vue';
import JhiGatewayComponent from '../components/admin/gateway/Gateway.vue'; // jhipster-needle-add-entity-to-router-import - JHipster will import entities to the router here

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/register',
      name: 'Register',
      component: Register
    },
    {
      path: '/resetPassword',
      name: 'ResetPassword',
      component: ResetPassword
    },
    {
      path: '/account/password',
      name: 'ChangePassword',
      component: ChangePassword
    },
    {
      path: '/account/sessions',
      name: 'Sessions',
      component: Sessions
    },
    {
      path: '/account/settings',
      name: 'Settings',
      component: Settings
    },
    {
      path: '/admin/user-management',
      name: 'JhiUser',
      component: JhiUserManagementComponent
    },
    {
      path: '/admin/user-management/new',
      name: 'JhiUserCreate',
      component: JhiUserManagementEditComponent
    },
    {
      path: '/admin/user-management/:userId/edit',
      name: 'JhiUserEdit',
      component: JhiUserManagementEditComponent
    },
    {
      path: '/admin/user-management/:userId/view',
      name: 'JhiUserView',
      component: JhiUserManagementViewComponent
    },
    {
      path: '/admin/docs',
      name: 'JhiDocsComponent',
      component: JhiDocsComponent
    },
    {
      path: '/admin/audits',
      name: 'JhiAuditsComponent',
      component: JhiAuditsComponent
    },
    {
      path: '/admin/jhi-health',
      name: 'JhiHealthComponent',
      component: JhiHealthComponent
    },
    {
      path: '/admin/logs',
      name: 'JhiLogsComponent',
      component: JhiLogsComponent
    },
    {
      path: '/admin/jhi-metrics',
      name: 'JhiMetricsComponent',
      component: JhiMetricsComponent
    },
    {
      path: '/admin/jhi-configuration',
      name: 'JhiConfigurationComponent',
      component: JhiConfigurationComponent
    },
    {
      path: '/admin/gateway',
      name: 'JhiGatewayComponent',
      component: JhiGatewayComponent
    }
    // jhipster-needle-add-entity-to-router - JHipster will add entities to the router here
  ]
});
