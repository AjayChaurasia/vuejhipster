<script>

    export default {
        data () {
            return {
                languages:
                    {
        }
                    // jhipster-needle-i18n-language-key-pipe - JHipster will add/remove languages in this object

            }
        }
    }
</script>
