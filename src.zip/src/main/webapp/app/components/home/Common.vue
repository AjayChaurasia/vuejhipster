<script>
import axios from 'axios';

export const OPTION =axios.create({
baseURL: 'http://localhost:9200/party/_doc/',
headers:{
Authorization: 'ABC'
}
})
</script>





fetch("http://localhost:8082/v2/api-docs").then(response => response.json()).then((data)=>{this.user_data=data;})