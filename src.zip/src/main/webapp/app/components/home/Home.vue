<template>
  <v-container>
    <div class="right" id="App">
    <template>
        <div>
            
            <md-table v-model="this.arr" md-sort="name" md-sort-order="asc" md-card="true">
                <md-table-toolbar>
                    <h1 class="md-title">Customer List</h1>
                </md-table-toolbar>

                
                <md-table-row slot="md-table-row" slot-scope="{ item }">
                    <md-table-cell md-label="Party ID" md-numeric>{{ item.PARTY_ID }}</md-table-cell>
                    <md-table-cell md-label="First Name" md-sort-by="First Name">{{ item.FIRST_NAME}}</md-table-cell>
                    <md-table-cell md-label="Middle Name" md-sort-by="Middle Name">{{ item.MIDDLE_NAME }}</md-table-cell>
                    <md-table-cell md-label="Last Name" md-sort-by="Last Name">{{ item.LAST_NAME }}</md-table-cell>
                    <md-table-cell md-label="Gender" md-sort-by="Gender">{{ item.GENDER }}</md-table-cell>
                    <md-table-cell md-label="DOB" md-sort-by="DOB">{{ item.DOB }}</md-table-cell>
                    <md-table-cell md-label="Account Type" md-sort-by="Account Type">{{ item.Customer_Type }}</md-table-cell>
                </md-table-row>
            </md-table>
         </div>
    </template>
    </div>
    <v-card color="transparent" height="900" width="700">
    <v-layout align-left justify-center>
    <div class="left">
    <template>
        <v-form ref="form" v-model="valid" lazy-validation>
           <v-text-field v-model="firstname" :rules="fnameRules" :counter="20" label="First Name" required outline></v-text-field>
			<v-text-field v-model="lastname"  :counter="20" label="Last Name" required outline></v-text-field>
			<v-text-field v-model="nationalId" label="National ID" required outline></v-text-field>
			<h3><b>Gender:</b></h3>
			<v-radio-group v-model="gender" gender>
				<v-radio label="Male" value="radio-1"></v-radio>
				<v-radio label="Female" value="radio-2"></v-radio>
				<v-radio label="Others" value="radio-3"></v-radio>
			</v-radio-group>
			<h3><b>Customer Type: </b></h3>
			<v-radio-group v-model="customerType" customerType>
				<v-radio label="Enterprise" value="radio-4"></v-radio>
				<v-radio label="Personal" value="radio-5"></v-radio>
			</v-radio-group>
            <v-btn style="color:#fff;background-color:purple;border-color:purple;" :disabled="!valid" @click="getPosts">Search</v-btn>
            <v-btn @click="clear" style="color:#fff;background-color:purple;border-color:purple;">clear</v-btn>
        </v-form>
    </template>
    </div>
    </v-layout>
    </v-card>
  </v-container>
</template>    

 
<script>
import Vue from 'vue';
import axios from 'axios';
import swal from 'sweetalert';
import Vuetify from 'vuetify';
import GroupButton from 'vue-libs-radio-group';
import {Searchbox, SearchDatalist, RefinementListFilter, Paginate, SearchButton, ResetButton, Hits, Generics, NumericListFilter} from 'vue-innersearch/src/innerSearch';
Vue.component('searchbox', Searchbox);
Vue.component('search-datalist', SearchDatalist);
Vue.component('refinement-list-filter', RefinementListFilter);
Vue.component('paginate', Paginate);
Vue.component('search-button', SearchButton);
Vue.component('reset-button', ResetButton);
Vue.component('hits', Hits);
Vue.component('numeric-list-filter', NumericListFilter);
Vue.component('group-button', GroupButton);
Vue.component('md-table-cell', {  });
Vue.component('text-field', {  });
Vue.component('md-table-row', {  });
Vue.component('md-table', {  });
Vue.component('form', {  });
import 'vue-material/dist/vue-material.min.css'

Vue.mixin(Generics);

export default 
{
    name: 'App',
    components: 
    { 
      
    },
    data ()
    {
      
        return{
            search: null,
            searched: [],
            arr:[],
            user1_data:[],
            respons: '',
            valid: true,
            firstname: '',
            fnameRules: [
            v => !!v || 'First Name is required',
            v => (v && v.length <= 20) || 'First Name must be less than 20 characters'
            ],
            lastname: '',
            lnameRules: [
            v => !!v || 'Last Name is required',
            v => (v && v.length <= 20) || 'Last Name must be less than 20 characters'
            ],
            middleName: '',
            gender: '',
            genderRules: [ v => !!v || 'Gender is required'],
            customerType: '',
            customerTypeRules: [ v => !!v || ' Customer Type is required'],
            response: '' 
        };
    },
    methods: {
        getPosts(){
            if (this.$refs.form.validate()){
                if(this.lastname.length){
                axios({method: 'GET', url: 'http://localhost:8091/loanoriginationmicroservice/retail/v1/party1/firstName='+this.firstname+" AND lastName="+ this.lastname+" "+this.middleName+" AND gender="+this.gender+" AND partySubTypeDescription="+this.customerType, headers: {Authorization: 'ABC' ,'Ocp-Apim-Subscription-Key': 'ABCD' , 'X-Request-ID': '94943ef4-5ee8-4cb6-b7f3-a12b64c21487',withCredentials: false, crossDomain: true }})                
                .then(response => {
                                        this.user1_data = response.data;
                                        if(this.user1_data.length){
                                            this.arr=[];
                                            for(var i=0;i<(this.user1_data.length)/2;i++){
                                                this.arr.push({"PARTY_ID":this.user1_data[i+(i+1)].partyID, 
                                                                "FIRST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].firstName,
                                                                "MIDDLE_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].MiddleName,
                                                                "LAST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].lastName,
                                                                "GENDER":this.user1_data[i+i].genderDescription,
                                                                "DOB":this.user1_data[i+i].dateOfBirth,
                                                                "Customer_Type":this.user1_data[i+(i+1)].partySubTypeDescription});
                                            }   
                                        }
                                        else{
                                            this.arr=[];
                                            swal ( "Oops" ,  "No Data Found" ,  "error" ) 
                                        }
                                    }); 
            }
            else if(this.middleName.length){
                    axios({method: 'GET', url: 'http://localhost:8091/loanoriginationmicroservice/retail/v1/party1/firstName='+this.firstname+" "+ this.lastname+" AND MiddleName="+this.middleName+" AND gender="+this.gender+"   AND partySubTypeDescription="+this.customerType, headers: {Authorization: 'ABC' ,'Ocp-Apim-Subscription-Key': 'ABCD' , 'X-Request-ID': '94943ef4-5ee8-4cb6-b7f3-a12b64c21487',withCredentials: false, crossDomain: true }})                
                    .then(response => {
                                        this.user1_data = response.data;
                                        if(this.user1_data.length){
                                            this.arr=[];
                                            for(var i=0;i<(this.user1_data.length)/2;i++){
                                               this.arr.push({"PARTY_ID":this.user1_data[i+(i+1)].partyID, 
                                                                "FIRST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].firstName,
                                                                "MIDDLE_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].MiddleName,
                                                                "LAST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].lastName,
                                                                "GENDER":this.user1_data[i+i].genderDescription,
                                                                "DOB":this.user1_data[i+i].dateOfBirth,
                                                                "Customer_Type":this.user1_data[i+(i+1)].partySubTypeDescription});
                                            }
                                        }   
                                        else{
                                            this.arr=[];
                                            swal ( "Oops" ,  "No Data Found" ,  "error" ) 
                                        }
                                    }); 
            }
            else if(this.middleName.length && this.lastname.length){
                    axios({method: 'GET', url: 'http://localhost:8091/loanoriginationmicroservice/retail/v1/party1/firstName='+this.firstname+" AND lastName="+ this.lastname+" AND MiddleName="+this.middleName+" AND gender="+this.gender+"   AND partySubTypeDescription="+this.customerType, headers: {Authorization: 'ABC' ,'Ocp-Apim-Subscription-Key': 'ABCD' , 'X-Request-ID': '94943ef4-5ee8-4cb6-b7f3-a12b64c21487',withCredentials: false, crossDomain: true }})                
                    .then(response => {
                                        this.user1_data = response.data;
                                        if(this.user1_data.length){
                                            this.arr=[];
                                            for(var i=0;i<(this.user1_data.length)/2;i++){
                                               this.arr.push({"PARTY_ID":this.user1_data[i+(i+1)].partyID, 
                                                                "FIRST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].firstName,
                                                                "MIDDLE_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].MiddleName,
                                                                "LAST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].lastName,
                                                                "GENDER":this.user1_data[i+i].genderDescription,
                                                                "DOB":this.user1_data[i+i].dateOfBirth,
                                                                "Customer_Type":this.user1_data[i+(i+1)].partySubTypeDescription});
                                            }
                                        }   
                                        else{
                                            this.arr=[];
                                            swal ( "Oops" ,  "No Data Found" ,  "error" ) 
                                        }
                                    }); 
            }
            else if(this.firstname.length){
                axios({method: 'GET', url: 'http://localhost:8091/loanoriginationmicroservice/retail/v1/party1/firstName='+this.firstname+" "+ this.lastname+" "+this.middleName+" AND gender="+this.gender+" AND partySubTypeDescription="+this.customerType, headers: {Authorization: 'ABC' ,'Ocp-Apim-Subscription-Key': 'ABCD' , 'X-Request-ID': '94943ef4-5ee8-4cb6-b7f3-a12b64c21487',withCredentials: false, crossDomain: true }})                
                .then(response => {
                                        this.user1_data = response.data;
                                        if(this.user1_data.length){
                                            this.arr=[];
                                            for(var i=0;i<(this.user1_data.length)/2;i++){
                                                this.arr.push({"PARTY_ID":this.user1_data[i+(i+1)].partyID, 
                                                                "FIRST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].firstName,
                                                                "MIDDLE_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].MiddleName,
                                                                "LAST_NAME":this.user1_data[i+i].previousOrOtherNameDetails[0].lastName,
                                                                "GENDER":this.user1_data[i+i].genderDescription,
                                                                "DOB":this.user1_data[i+i].dateOfBirth,
                                                                "Customer_Type":this.user1_data[i+(i+1)].partySubTypeDescription});
                                            }
                                        }   
                                        else{
                                            this.arr=[];
                                            swal ( "Oops" ,  "No Data Found" ,  "error" ) 
                                        }
                                    }); 
            }
            else{
              this.arr=[];
                swal ( "Oops" ,  "Enter the data and Train Again" ,  "error" )
            }}},
            clear (){
              this.firstname ='';   
              this.lastname ='';
              this.gender='';
              this.middleName='';
              this.customerType='';
           }
  }
}
</script>
<style>
@import url(./vueye-table1.css);
div.right {
        width: 70%; 
        padding: 0 0 0 5%;
        float: left;
}
</style>
