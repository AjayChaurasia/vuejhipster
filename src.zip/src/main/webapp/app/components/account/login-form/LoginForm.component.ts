import axios from 'axios';
import Principal from '../Principal.vue';

const LoginForm = {
  mixins: [Principal],
  data() {
    return {
      authenticationError: null,
      login: null,
      password: null,
      rememberMe: null
    };
  },
  methods: {
    doLogin: function() {
      let vm = this;
      const data = { username: this.login, password: this.password, rememberMe: this.rememberMe };
      axios
        .post('api/authenticate', data)
        .then(function(result) {
          const bearerToken = result.headers.authorization;
          if (bearerToken && bearerToken.slice(0, 7) === 'Bearer ') {
            const jwt = bearerToken.slice(7, bearerToken.length);
            if (vm.rememberMe) {
              localStorage.setItem('jhi-authenticationToken', jwt);
            } else {
              sessionStorage.setItem('jhi-authenticationToken', jwt);
            }
          }
          vm.authenticationError = false;
          vm.$root.$emit('bv::hide::modal', 'login-page');
          vm.retrieveAccount();
        })
        .catch(() => {
          this.authenticationError = true;
        });
    }
  },
  watch: {
    $route() {
      this.$root.$emit('bv::hide::modal', 'login-page');
    }
  }
};

export default LoginForm;
