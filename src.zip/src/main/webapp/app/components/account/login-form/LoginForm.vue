<template>
    <div class="modal-body">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <b-alert show variant="danger" v-if="authenticationError" >
                    <strong>Failed to sign in!</strong> Please check your credentials and try again.
                </b-alert>
            </div>
            <div class="col-md-8">
                <b-form role="form" v-on:submit.prevent="doLogin()">
                    <b-form-group  label-for="username">
                        <b-form-input id="username" type="text" name="username" autofocus  v-model="login">
                        </b-form-input>
                    </b-form-group>
                    <b-form-group  label-for="password">
                        <b-form-input id="password" type="password" name="password" v-model.trim="name"  v-model="password">
                        </b-form-input>
                    </b-form-group>
                    <b-form-checkbox id="rememberMe" name="rememberMe" v-model="rememberMe" checked text="$t('login.form.rememberme')">
                        Remember me
                    </b-form-checkbox>
                    <div>
                        <b-button type="submit" variant="primary" >Sign in</b-button>
                    </div>
                </b-form>
                <p></p>
                <div>
                    <b-alert show variant="warning">
                        <b-link :to="'/resetPassword'" class="alert-link" >Did you forget your password ?</b-link>
                    </b-alert>
                </div>
                <div>
                    <b-alert show variant="warning">
                        You don't have an account yet ?
                        <b-link :to="'/register'" class="alert-link" >Register a new account</b-link>
                    </b-alert>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" src="./LoginForm.component.ts">
</script>
