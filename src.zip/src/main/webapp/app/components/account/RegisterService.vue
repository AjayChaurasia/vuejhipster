<script>
    import axios from 'axios'

    export default {
        name: 'RegisterService',
        methods: {
            processRegistration: function(account) {
                return axios.post('api/register', account);
            }
        }
    }
</script>
