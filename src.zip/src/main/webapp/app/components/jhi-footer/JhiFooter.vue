<template>
    <div class="footer">
        <p>Party HomePage</p>
    </div>
</template>
<script lang="ts" src="./JhiFooter.component.ts">
</script>
<style scoped>
    .footer {
        position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
  background-color: white;
    color: blueviolet;
    text-align: left;
            }
</style>
