const JhiFooter = {
  name: 'JhiFooter'
};

export default JhiFooter;
