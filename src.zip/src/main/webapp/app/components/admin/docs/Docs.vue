<template>
    <iframe src="/swagger-ui/index.html" width="100%" height="900" seamless
            target="_top" title="Swagger UI" class="border-0"></iframe>
</template>
<p>This is Swagger Docs</p>
<script lang="ts" src="./Docs.component.ts">
</script>

<style scoped>

</style>
