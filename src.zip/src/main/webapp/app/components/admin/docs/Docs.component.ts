const JhiDocsComponent = {
  name: 'JhiDocsComponent'
};

export default JhiDocsComponent;
