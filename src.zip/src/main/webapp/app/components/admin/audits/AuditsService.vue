<script>
    import axios from 'axios';

    export default {
        name: 'AuditsService',
        methods: {
            query: function(req) {
                let sorts = '';
                for (let idx in req.sort) {
                    if (sorts.length > 0) {
                        sorts += '&';
                    }
                    sorts += 'sort=' + req.sort[idx];
                }
                return axios.get(`management/audits?fromDate=${req.fromDate}&toDate=${req.toDate}&${sorts}&page=${req.page}&size=${req.size}`);
            }
        }
    }
</script>
