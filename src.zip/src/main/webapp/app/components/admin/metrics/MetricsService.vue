<script>
    import axios from 'axios';

    export default {
        name: 'MetricsService',
        methods: {
            getMetrics: function() {
                return axios.get('management/metrics');
            },
            retrieveThreadDump: function() {
                return axios.get( 'management/threaddump');
            }
        }
    }
</script>
