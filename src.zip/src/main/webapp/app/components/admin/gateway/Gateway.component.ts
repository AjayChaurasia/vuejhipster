import GatewayService from './GatewayService.vue';

const JhiGatewayComponent = {
  name: 'JhiGatewayComponent',
  mixins: [GatewayService],
  beforeRouteEnter(to, from, next) {
    next(vm => {
      vm.init();
    });
  },
  data() {
    return {
      gatewayRoutes: [],
      updatingRoutes: false
    };
  },
  methods: {
    init() {
      this.refresh();
    },
    refresh() {
      this.updatingRoutes = true;
      let vm = this;
      this.findAll().then(function(res) {
        vm.gatewayRoutes = res.data;
        vm.updatingRoutes = false;
      });
    }
  }
};

export default JhiGatewayComponent;
