import '@babel/polyfill'
import Vue from 'vue'
import vcard from'v-card'
import Vuetify from 'vuetify'
import Vuex from './node_module/vuex';
import Router from 'vue-router'
import 'vuetify/dist/vuetify.min.css'
import './plugins/vuetify'
import router from './router'
import App from './webapp/app/components/App.vue'
import VueResource from 'vue-resource'
import InnerSearch from 'vue-innersearch/src/innerSearch'
import {
  Vuetify,
  VApp,
  VCard,
  VList,VTextField,VRadio
} from 'vuetify';
import './stylus/main.styl'
Vue.use(Vuetify);
Vue.use(vcard);
Vue.use(VueResource);
Vue.use(Router);
Vue.use(Vuex);
Vue.use(router);
const Vuetify = require("vuetify").default;
Vue.component('tags-input', require('@voerro/vue-tagsinput').default);
Vue.config.productionTip = false;
import {Searchbox, Hits, Generics} from 'vue-innersearch/src/innerSearch';
import axios from 'axios';
import { MdButton, MdContent, MdTabs } from 'vue-material/dist/components';
import GroupButton from 'vue-libs-radio-group';
Vue.prototype.$axios = axios;
Vue.component('searchbox', Searchbox);
Vue.component('hits', Hits);
Vue.use(GroupButton);
Vue.use(InnerSearch)
Vue.mixin(Generics);
Vue.use(InnerSearch);
Vue.use(VueMaterial);
Vue.use(MdButton);
Vue.use(MdContent);
Vue.use(MdTabs);
Vue.component('group-button', GroupButton);



Vue.config.ignoredElements = [
  'v-icon', 'v-card', 'v-card-text', 'v-container', 'v-layout', 'v-form','v-btn', 'md-table-cell','v-radio-group','v-radio' 
];

import VueMaterial from 'vue-material';
import 'vue-material/dist/vue-material.min.css';
import 'vue-material/dist/theme/default.css';
new Vue({
  render: h => h(App)
}).$mount('#app')
Vue.use(Vuetify,{
  components: {
    VApp,
    VCard,
    VList,VTextField,VRadio
  }
});

