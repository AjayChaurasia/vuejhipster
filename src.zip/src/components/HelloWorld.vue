<template>
 
  <v-app>
    <v-toolbar app>
      <v-toolbar-title class="headline text-uppercase">
		<span><img src="./finastralogo.png" width="25%" height="20%" alt="avatar"></span>
      </v-toolbar-title>
      <v-spacer></v-spacer>
		
      <v-btn flat href="https://www.finastra.com/solutions/products" target="_blank">
        <span class="mr-2">Releases</span>
      </v-btn>
    </v-toolbar>
	
    <v-content>	
		<v-toolbar color="purple" dark>
			<v-toolbar-title>Customer Search</v-toolbar-title>
			<v-divider class="mx-3" inset vertical></v-divider>
			<span class="subheading"></span>
			<v-spacer></v-spacer>
		</v-toolbar>
		<HelloWorld/>
    </v-content>
  </v-app>
</template>

<script>

import HelloWorld from './components/HelloWorld'

export default 
{
	name: 'App',
	components: {
		HelloWorld
	},
	data () 
	{
	
return {
			
			
		};
	}
}
	
</script>